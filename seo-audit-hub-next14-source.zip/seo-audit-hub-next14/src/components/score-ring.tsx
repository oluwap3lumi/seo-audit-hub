export function ScoreRing({ score }: { score: number }) {
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  const color = score >= 80 ? '#20b77a' : score >= 50 ? '#eeaa40' : '#e96375';
  return (
    <div className="relative w-[174px] h-[174px]" role="img" aria-label={`SEO score ${score} out of 100`}>
      <svg viewBox="0 0 174 174" aria-hidden="true">
        <circle cx="87" cy="87" r={radius} stroke="var(--stroke)" strokeWidth="13" fill="none" />
        <circle cx="87" cy="87" r={radius} stroke={color} strokeWidth="13" fill="none"
          strokeLinecap="round" strokeDasharray={circumference}
          strokeDashoffset={circumference * (1 - score / 100)}
          transform="rotate(-90 87 87)" style={{ transition: 'stroke-dashoffset 700ms' }} />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <strong className="text-[47px] tracking-tight leading-none">{score}</strong>
        <span className="muted text-xs mt-1">out of 100</span>
      </div>
    </div>
  );
}
