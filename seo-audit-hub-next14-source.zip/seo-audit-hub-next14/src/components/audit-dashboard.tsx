'use client';

import { FormEvent, useEffect, useMemo, useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import {
  ArrowRight, Check, CheckCircle2, ChevronDown, CircleAlert,
  Clipboard, Download, ExternalLink, FileSearch, FileText, Globe2,
  History, Image as PictureIcon, Link2, LoaderCircle, Moon, Search,
  ShieldCheck, Sparkles, Sun, Target, Trash2, TriangleAlert, X, Zap
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScoreRing } from '@/components/score-ring';
import { normalizeUrl } from '@/lib/url';
import type { AuditCheck, AuditResult, Category, Status } from '@/lib/types';

const STORAGE_KEY = 'seo-audit-hub-recent-v1';
const THEME_KEY = 'seo-audit-hub-theme-v1';
const STAGES = ['Fetching website', 'Analyzing metadata', 'Checking headings and links', 'Inspecting technical SEO', 'Generating report'];
const TABS: { id: Category; name: string }[] = [
  { id: 'meta', name: 'Meta & content' },
  { id: 'social', name: 'Social & mobile' },
  { id: 'media', name: 'Media & links' },
  { id: 'technical', name: 'Technical SEO' }
];

function dateLabel(date: string): string {
  return new Date(date).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
}
function StatusTag({ status }: { status: Status }) {
  const classes = {
    pass: 'text-emerald-700 bg-emerald-50 dark:text-emerald-300 dark:bg-emerald-950/40',
    warning: 'text-amber-700 bg-amber-50 dark:text-amber-300 dark:bg-amber-950/40',
    error: 'text-rose-700 bg-rose-50 dark:text-rose-300 dark:bg-rose-950/40'
  };
  return <span className={'text-[11px] font-bold rounded-full px-2.5 py-1 ' + classes[status]}>
    {status === 'pass' ? 'Passed' : status === 'warning' ? 'Warning' : 'Critical'}
  </span>;
}
function CheckRow({ check }: { check: AuditCheck }) {
  return <details className="border-t border-[var(--stroke)] first:border-t-0 group">
    <summary className="cursor-pointer list-none p-5 flex items-start gap-3">
      {check.status === 'pass' ? <CheckCircle2 size={18} className="text-emerald-500 shrink-0" /> :
        check.status === 'warning' ? <TriangleAlert size={18} className="text-amber-500 shrink-0" /> :
          <CircleAlert size={18} className="text-rose-500 shrink-0" />}
      <div className="min-w-0 flex-1">
        <div className="flex items-start flex-wrap gap-2 justify-between">
          <h4 className="font-semibold text-sm">{check.label}</h4><StatusTag status={check.status} />
        </div>
        <p className="muted text-xs leading-relaxed mt-2">{check.detail}</p>
      </div>
      <ChevronDown size={16} className="muted shrink-0 transition-transform group-open:rotate-180 mt-1" />
    </summary>
    <div className="mx-5 ml-12 mb-4 bg-[var(--bg)] rounded-xl p-4">
      <p className="uppercase tracking-widest font-bold text-xs text-brand-600">How to fix it</p>
      <p className="text-sm muted leading-relaxed mt-2">{check.recommendation}</p>
    </div>
  </details>;
}
function getReportSummary(report: AuditResult): string {
  const fixes = report.checks.filter(c => c.status !== 'pass').slice(0, 5);
  return [
    `SEO Audit Hub: ${report.url}`,
    `Score: ${report.score}/100`,
    `Critical: ${report.summary.errors}, warnings: ${report.summary.warnings}, passed: ${report.summary.passed}`,
    `Date: ${dateLabel(report.auditedAt)}`,
    `Content: ${report.metrics.wordCount} words, ${report.metrics.images} images, ${report.metrics.internalLinks} internal links`,
    '',
    'Recommended fixes:',
    ...(fixes.length ? fixes.map(f => `- ${f.label}: ${f.recommendation}`) : ['- No issues detected by these checks.']),
    '',
    'Single-page heuristic audit. Not a ranking or Core Web Vitals assessment.'
  ].join('\n');
}
function savedReports(): AuditResult[] {
  try {
    const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(value) ? value.filter((item): item is AuditResult =>
      !!item && typeof item.url === 'string' && Array.isArray(item.checks)).slice(0, 10) : [];
  } catch { return []; }
}

export function AuditDashboard() {
  const [input, setInput] = useState('');
  const [error, setError] = useState('');
  const [result, setResult] = useState<AuditResult | null>(null);
  const [dark, setDark] = useState(false);
  const [history, setHistory] = useState<AuditResult[]>([]);
  const [historyVisible, setHistoryVisible] = useState(false);
  const [tab, setTab] = useState<Category>('meta');
  const [filter, setFilter] = useState<'all' | 'issues' | 'passed'>('all');
  const [stage, setStage] = useState(0);
  const [toast, setToast] = useState('');

  useEffect(() => {
    setHistory(savedReports());
    try { setDark(localStorage.getItem(THEME_KEY) === 'dark'); } catch { /* optional storage */ }
  }, []);
  useEffect(() => {
    try { localStorage.setItem(THEME_KEY, dark ? 'dark' : 'light'); } catch { /* optional storage */ }
  }, [dark]);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(''), 3200);
    return () => clearTimeout(timer);
  }, [toast]);

  const audit = useMutation({
    mutationFn: async (url: string): Promise<AuditResult> => {
      const response = await fetch('/api/audit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
      });
      const data: unknown = await response.json();
      if (!response.ok) {
        const payload = data as { error?: string };
        throw new Error(payload.error || `Server returned HTTP ${response.status}`);
      }
      return data as AuditResult;
    },
    onSuccess: data => {
      setResult(data);
      setError('');
      setTab('meta');
      setFilter('all');
      setHistory(previous => {
        const next = [data, ...previous.filter(item => item.url !== data.url)].slice(0, 10);
        try { localStorage.setItem(STORAGE_KEY, JSON.stringify(next)); } catch { /* optional storage */ }
        return next;
      });
      setTimeout(() => document.querySelector('#results')?.scrollIntoView({ behavior: 'smooth' }), 80);
    },
    onError: (err: Error) => setError(err.message)
  });
  useEffect(() => {
    if (!audit.isPending) return;
    setStage(0);
    const timer = setInterval(() => setStage(v => Math.min(v + 1, STAGES.length - 1)), 1600);
    return () => clearInterval(timer);
  }, [audit.isPending]);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError('');
    try { audit.mutate(normalizeUrl(input)); }
    catch (err) { setError(err instanceof Error ? err.message : 'Enter a valid URL.'); }
  }
  async function copy() {
    if (!result) return;
    try { await navigator.clipboard.writeText(getReportSummary(result)); setToast('Summary copied to clipboard'); }
    catch { setToast('Unable to access clipboard in this browser'); }
  }
  function openReport(report: AuditResult) {
    setResult(report);
    setInput(report.url);
    setHistoryVisible(false);
    setTab('meta');
    setFilter('all');
    setTimeout(() => document.querySelector('#results')?.scrollIntoView({ behavior: 'smooth' }), 60);
  }
  function clearAudits() {
    if (!window.confirm('Remove all locally saved audit reports?')) return;
    setHistory([]);
    try { localStorage.removeItem(STORAGE_KEY); } catch { /* optional storage */ }
    setToast('Saved audits cleared');
  }
  const visibleChecks = useMemo(() => result?.checks.filter(check =>
    check.category === tab && (filter === 'all' || (filter === 'issues' ? check.status !== 'pass' : check.status === 'pass'))
  ) || [], [result, tab, filter]);
  const priorities = useMemo(() => result?.checks.filter(check => check.status !== 'pass').sort((a, b) =>
    (a.status === 'error' ? 0 : 1) - (b.status === 'error' ? 0 : 1) || b.weight - a.weight).slice(0, 4) || [], [result]);

  return <div className={dark ? 'app-root dark' : 'app-root'} id="top">
    <header className="surface border-b sticky top-0 z-20 no-print">
      <div className="max-w-7xl h-[76px] px-5 sm:px-8 mx-auto flex items-center justify-between">
        <a href="#top" className="flex gap-3 items-center font-bold text-lg tracking-tight">
          <span className="w-10 h-10 rounded-xl bg-brand-600 text-white flex items-center justify-center"><FileSearch size={23} /></span>
          SEO Audit <span className="text-brand-600 -ml-2">Hub</span>
        </a>
        <nav className="hidden md:flex gap-8 items-center text-sm font-medium muted">
          <a href="#top" className="hover:text-brand-600">Overview</a>
          <a href="#features" className="hover:text-brand-600">What we check</a>
          <button onClick={() => setHistoryVisible(true)} className="hover:text-brand-600">History</button>
        </nav>
        <div className="flex items-center gap-2">
          <span className="hidden sm:inline-block rounded-full bg-emerald-50 text-emerald-700 px-3 py-1.5 text-xs font-semibold dark:bg-emerald-950/30 dark:text-emerald-300">Free & no signup</span>
          <Button variant="secondary" size="sm" aria-label={dark ? 'Light mode' : 'Dark mode'} onClick={() => setDark(v => !v)} className="w-10 px-0">{dark ? <Sun size={18} /> : <Moon size={18} />}</Button>
          <Button variant="secondary" size="sm" aria-label="Recent audits" onClick={() => setHistoryVisible(true)} className="w-10 px-0 md:hidden"><History size={18} /></Button>
        </div>
      </div>
    </header>

    <main>
      <section className="hero-section relative overflow-hidden border-b border-[var(--stroke)] no-print">
        <div className="absolute inset-0 pointer-events-none hero-grid" />
        <div className="max-w-5xl relative mx-auto px-5 py-20 sm:py-24 text-center">
          <span className="inline-flex gap-2 items-center rounded-full surface border px-4 py-2 text-[11px] font-bold tracking-widest muted"><Sparkles size={14} className="text-brand-600" /> THE SMARTER WAY TO OPTIMIZE YOUR SITE</span>
          <h1 className="font-extrabold text-4xl sm:text-5xl lg:text-[60px] tracking-[-.045em] leading-[1.1] mt-7">Instantly Analyze Any<br className="hidden sm:block" /> Website's <span className="text-brand-600">On-Page SEO.</span></h1>
          <p className="muted text-base sm:text-lg mt-6 leading-relaxed max-w-[640px] mx-auto">Understand what's working, uncover what isn't, and get a clear roadmap to better search visibility. No signup, no guesswork.</p>
          <form className="max-w-[780px] mx-auto mt-10" onSubmit={submit} noValidate>
            <div className="surface shadow-xl shadow-violet-500/10 p-2 rounded-2xl flex flex-col sm:flex-row gap-2">
              <div className="flex flex-1 items-center gap-3 px-4 min-w-0"><Globe2 className="muted shrink-0" size={20} /><input id="site-url" value={input} onChange={e => { setInput(e.target.value); setError(''); }} disabled={audit.isPending} className="w-full bg-transparent outline-none h-12 text-sm sm:text-base placeholder:text-slate-400" placeholder="Enter website URL (e.g. example.com)" aria-label="Website URL" /></div>
              <Button disabled={audit.isPending} type="submit" className="h-[50px] px-6 shrink-0">{audit.isPending ? <><LoaderCircle size={18} className="animate-spin" /> Auditing site...</> : <><Search size={18} /> Audit Website <ArrowRight size={16} /></>}</Button>
            </div>
            {error && <p role="alert" className="text-rose-500 text-sm mt-3 flex justify-center items-center gap-2"><CircleAlert size={16} />{error}</p>}
            {audit.isPending && <p role="status" className="muted text-sm mt-5 flex justify-center items-center gap-2"><span className="h-2 w-2 rounded-full bg-brand-600 animate-pulse" />{STAGES[stage]}...</p>}
          </form>
          <div className="flex flex-wrap justify-center gap-5 sm:gap-8 mt-7 text-xs sm:text-sm muted">
            <span className="flex gap-2 items-center"><CheckCircle2 size={16} className="text-emerald-500" /> 100% free to use</span>
            <span className="flex gap-2 items-center"><ShieldCheck size={16} className="text-emerald-500" /> No account needed</span>
            <span className="flex gap-2 items-center"><Zap size={16} className="text-emerald-500" /> Actionable guidance</span>
          </div>
        </div>
      </section>

      {result ? <section id="results" className="report max-w-7xl mx-auto px-5 py-12 sm:px-8 sm:py-16 scroll-mt-24">
        <div className="flex flex-wrap items-start justify-between gap-5 mb-8">
          <div className="min-w-0">
            <p className="text-brand-600 text-xs font-bold uppercase tracking-widest mb-2">Your SEO health report</p>
            <h2 className="text-3xl font-extrabold tracking-tight">Audit overview <span className="text-brand-600">.</span></h2>
            <a className="flex items-center gap-2 muted hover:text-brand-600 text-sm mt-2 break-all" href={result.url} rel="noopener noreferrer" target="_blank">{result.url}<ExternalLink size={14} /></a>
            <p className="muted text-xs mt-1">Scanned {dateLabel(result.auditedAt)} · Single-page heuristic report</p>
          </div>
          <div className="flex items-center gap-2 no-print">
            <Button variant="secondary" size="sm" onClick={copy}><Clipboard size={15} /> Copy summary</Button>
            <Button size="sm" onClick={() => window.print()}><Download size={15} /> Export PDF</Button>
          </div>
        </div>
        <div className="grid lg:grid-cols-[1fr_1.55fr] gap-5">
          <Card className="flex flex-col sm:flex-row lg:flex-col xl:flex-row items-center gap-6">
            <ScoreRing score={result.score} />
            <div className="text-center sm:text-left lg:text-center xl:text-left">
              <p className="uppercase tracking-widest muted text-xs font-bold">Overall SEO score</p>
              <p className="text-xl font-bold mt-2">{result.score >= 80 ? 'Strong foundation' : result.score >= 50 ? 'Room to improve' : 'Needs attention'}</p>
              <p className="muted mt-2 text-xs max-w-[220px] leading-relaxed">Calculated from {result.checks.length} weighted SEO checks.</p>
              <p className="muted text-[11px] mt-4">🔴 0–49 &nbsp; 🟡 50–79 &nbsp; 🟢 80+</p>
            </div>
          </Card>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { label: 'Critical errors', value: result.summary.errors, Icon: CircleAlert, cls: 'text-rose-500 bg-rose-50 dark:bg-rose-950/30' },
              { label: 'Warnings', value: result.summary.warnings, Icon: TriangleAlert, cls: 'text-amber-500 bg-amber-50 dark:bg-amber-950/30' },
              { label: 'Passed checks', value: result.summary.passed, Icon: CheckCircle2, cls: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/30' }
            ].map(metric => <Card key={metric.label} className="flex flex-col justify-center">
              <div className={'w-11 h-11 rounded-xl flex items-center justify-center ' + metric.cls}><metric.Icon size={23} /></div>
              <strong className="text-4xl tracking-tight mt-6">{metric.value}</strong>
              <p className="muted text-sm mt-1">{metric.label}</p>
            </Card>)}
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-5">
          {[
            { name: 'Word count', value: result.metrics.wordCount, Icon: FileText },
            { name: 'Images analyzed', value: result.metrics.images, Icon: PictureIcon },
            { name: 'Internal links', value: result.metrics.internalLinks, Icon: Link2 },
            { name: 'Text / HTML', value: `${result.metrics.textHtmlRatio}%`, Icon: FileSearch }
          ].map(metric => <Card key={metric.name} className="p-5"><p className="muted text-xs font-semibold flex items-center gap-2"><metric.Icon size={16} /> {metric.name}</p><p className="text-2xl font-bold mt-3">{metric.value}</p></Card>)}
        </div>
        <div className="grid lg:grid-cols-[1.6fr_1fr] gap-6 items-start mt-9">
          <div className="min-w-0">
            <h3 className="font-extrabold text-xl mb-4">Detailed audit results</h3>
            <div className="surface border rounded-2xl overflow-hidden">
              <div className="no-print flex p-3 gap-1 overflow-x-auto border-b border-[var(--stroke)]">
                {TABS.map(item => <button key={item.id} className={'tab-btn ' + (tab === item.id ? 'selected' : '')} onClick={() => { setTab(item.id); setFilter('all'); }}>{item.name}</button>)}
              </div>
              <div className="filter-bar p-5 flex gap-3 items-center justify-between flex-wrap border-b border-[var(--stroke)]">
                <div><h4 className="text-sm font-semibold">{TABS.find(t => t.id === tab)?.name}</h4><p className="muted text-xs mt-1">Select a check to see how to fix it.</p></div>
                <div className="flex bg-[var(--bg)] p-1 rounded-lg gap-1">
                  {(['all', 'issues', 'passed'] as const).map(item => <button key={item} onClick={() => setFilter(item)} className={'text-xs font-semibold rounded-md px-3 py-2 ' + (filter === item ? 'bg-brand-50 text-brand-700 dark:bg-slate-700 dark:text-white' : 'muted')}>{item === 'all' ? 'All' : item === 'issues' ? 'Issues' : 'Passed'}</button>)}
                </div>
              </div>
              <div className="screen-checks">{visibleChecks.length ? visibleChecks.map(check => <CheckRow key={check.id} check={check} />) : <p className="muted text-center p-12 text-sm">No checks match this filter.</p>}</div>
              <div className="print-checks hidden">{TABS.map(category => <div key={category.id}><h4 className="text-lg font-bold p-4">{category.name}</h4>{result.checks.filter(check => check.category === category.id).map(check => <div key={check.id} className="border-t px-4 py-2 text-sm"><strong>{check.label} — {check.status}</strong><p>{check.detail}</p><p>Fix: {check.recommendation}</p></div>)}</div>)}</div>
            </div>
          </div>
          <aside className="space-y-5">
            <Card><h3 className="font-extrabold text-lg flex gap-2 items-center"><Target size={21} className="text-brand-600" /> Priority actions</h3>
              <p className="muted text-xs leading-relaxed mt-2 mb-5">Fix critical issues first, then work through warnings.</p>
              {priorities.length ? <div className="space-y-3">{priorities.map((issue, i) => <div key={issue.id} className="bg-[var(--bg)] border-l-[3px] border-amber-400 rounded-xl p-4">
                <div className="flex gap-3"><b className="text-brand-600 text-xs">{String(i + 1).padStart(2, '0')}</b><div><h4 className="text-sm font-bold">{issue.label}</h4><p className="muted text-xs mt-2 leading-relaxed">{issue.recommendation}</p></div></div>
              </div>)}</div> : <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/20 p-4 text-emerald-600 text-sm font-semibold">All checks passed!</div>}
            </Card>
            <Card><h3 className="font-extrabold text-lg">Heading hierarchy</h3>
              <div className="space-y-4 mt-5">{(['h1', 'h2', 'h3'] as const).map(key => <div key={key} className="flex gap-3 items-center"><span className="text-xs font-bold text-brand-600">{key.toUpperCase()}</span><div className="flex-1 bg-[var(--stroke)] rounded-full h-2 overflow-hidden"><div className="bg-brand-600 h-2 rounded-full" style={{ width: `${Math.min(100, result.metrics[key].length * 12)}%` }} /></div><strong className="w-5 text-right text-xs">{result.metrics[key].length}</strong></div>)}</div>
              {!!result.metrics.h1.length && <p className="muted border-t border-[var(--stroke)] text-xs leading-relaxed mt-5 pt-4">Main heading: {result.metrics.h1[0]}</p>}
            </Card>
            <div className="rounded-2xl bg-gradient-to-br from-brand-600 to-violet-400 text-white p-6"><Sparkles size={22} /><h3 className="text-lg font-bold mt-4">Small fixes. Big impact.</h3><p className="text-xs leading-relaxed mt-2 text-violet-100">Re-audit after making improvements to track your progress.</p><button onClick={() => { setInput(result.url); window.scrollTo({ top: 0, behavior: 'smooth' }); }} className="no-print font-semibold text-xs bg-white/20 rounded-lg px-4 py-3 mt-5">Run another audit →</button></div>
          </aside>
        </div>
        <p className="muted text-[11px] text-center mt-8">This heuristic scans one server-returned HTML page. It does not run JavaScript, measure Core Web Vitals, check search indexing, or predict rankings.</p>
      </section> : <section id="features" className="max-w-7xl mx-auto py-20 px-5 sm:px-8">
        <p className="text-brand-600 text-xs font-bold uppercase tracking-widest text-center">EVERY DETAIL MATTERS</p>
        <h2 className="font-extrabold text-3xl sm:text-4xl tracking-tight text-center mt-3">The insights you need, <span className="text-brand-600">all in one place.</span></h2>
        <p className="muted text-center max-w-xl mx-auto mt-4">Explore actionable signals across content, social, links, and the site's technical foundation.</p>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 mt-11">{[
          { Icon: FileText, name: 'Meta & content', text: 'Title, description, headings, word count, and HTML structure.' },
          { Icon: Sparkles, name: 'Social & mobile', text: 'Open Graph, Twitter cards, and mobile viewport.' },
          { Icon: PictureIcon, name: 'Media & links', text: 'Image alt attributes, internal/external links, and empty hrefs.' },
          { Icon: ShieldCheck, name: 'Technical SEO', text: 'HTTPS, robots.txt, and XML sitemap checks.' }
        ].map(item => <Card key={item.name} className="p-7"><span className="rounded-xl bg-brand-50 text-brand-600 w-12 h-12 inline-flex items-center justify-center"><item.Icon size={24} /></span><h3 className="font-bold mt-6">{item.name}</h3><p className="muted text-sm mt-2 leading-relaxed">{item.text}</p></Card>)}</div>
      </section>}
    </main>
    <footer className="no-print border-t border-[var(--stroke)]"><div className="max-w-7xl mx-auto px-5 py-8 sm:px-8 flex flex-wrap justify-between items-center gap-3"><span className="flex gap-2 items-center font-bold text-sm"><FileSearch size={17} className="text-brand-600" /> SEO Audit Hub</span><p className="muted text-xs">Clearer insights. Better websites.</p></div></footer>

    {historyVisible && <div className="no-print fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label="Recent audits">
      <button className="absolute inset-0 bg-black/60" onClick={() => setHistoryVisible(false)} aria-label="Close recent audits" />
      <div className="relative surface h-full w-full max-w-md shadow-2xl flex flex-col p-6 overflow-y-auto">
        <div className="flex items-center justify-between"><h2 className="font-extrabold text-xl flex gap-2 items-center"><History size={21} className="text-brand-600" /> Recent audits</h2><Button variant="secondary" size="sm" aria-label="Close drawer" onClick={() => setHistoryVisible(false)}><X size={16} /></Button></div>
        <p className="muted text-sm mt-3">Your 10 most recent scans are stored in this browser only.</p>
        {history.length ? <div className="flex-1 space-y-3 mt-7">{history.map(item => <button key={item.url} className="surface rounded-xl border w-full text-left p-4 flex items-center gap-4 hover:border-brand-500" onClick={() => openReport(item)}><strong className="bg-brand-50 dark:bg-slate-700 text-brand-600 w-11 h-11 shrink-0 rounded-xl flex items-center justify-center">{item.score}</strong><div className="min-w-0"><p className="text-sm font-semibold truncate">{new URL(item.url).hostname}</p><p className="muted text-xs mt-1">{dateLabel(item.auditedAt)}</p></div></button>)}</div> : <div className="flex-1 flex flex-col justify-center items-center text-center muted"><History size={35} /><p className="font-semibold mt-3">No audits yet</p><p className="text-xs mt-2">Your first saved report will show up here.</p></div>}
        {!!history.length && <Button variant="secondary" onClick={clearAudits} className="mt-5"><Trash2 size={16} className="text-rose-500" /> Clear history</Button>}
      </div>
    </div>}
    {toast && <div role="status" className="no-print fixed bottom-6 right-6 bg-slate-900 text-white shadow-2xl rounded-xl px-5 py-3 text-xs font-semibold flex gap-2 items-center"><Check size={16} className="text-emerald-400" />{toast}</div>}
  </div>;
}
