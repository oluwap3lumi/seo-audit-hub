import { ButtonHTMLAttributes } from 'react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';

const styles = cva('inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-wait', {
  variants: {
    variant: {
      primary: 'bg-brand-600 hover:bg-brand-700 text-white',
      secondary: 'surface border hover:border-brand-500',
      ghost: 'hover:bg-brand-50 dark:hover:bg-slate-800'
    },
    size: { default: 'h-11 px-5 text-sm', sm: 'h-9 px-4 text-xs' }
  },
  defaultVariants: { variant: 'primary', size: 'default' }
});

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof styles>;
export function Button({ className, variant, size, ...props }: ButtonProps) {
  return <button className={cn(styles({ variant, size }), className)} {...props} />;
}
