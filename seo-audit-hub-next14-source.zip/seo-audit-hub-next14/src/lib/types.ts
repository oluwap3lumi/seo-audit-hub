export type Status = 'pass' | 'warning' | 'error';
export type Category = 'meta' | 'social' | 'media' | 'technical';

export interface AuditCheck {
  id: string;
  category: Category;
  label: string;
  status: Status;
  detail: string;
  recommendation: string;
  weight: number;
}

export interface AuditMetrics {
  title: string;
  description: string;
  canonical: string;
  h1: string[];
  h2: string[];
  h3: string[];
  wordCount: number;
  textHtmlRatio: number;
  images: number;
  missingAlt: number;
  internalLinks: number;
  externalLinks: number;
  emptyLinks: number;
  robotsStatus: number | null;
  sitemapStatus: number | null;
}

export interface AuditResult {
  requestedUrl: string;
  url: string;
  auditedAt: string;
  score: number;
  summary: { errors: number; warnings: number; passed: number };
  metrics: AuditMetrics;
  checks: AuditCheck[];
}
