/**
 * Bounded HTTP(S) fetch that validates and pins a public DNS resolution for
 * each redirect hop. This protects the public audit endpoint from common SSRF
 * vectors, including redirects to internal hosts and basic DNS rebinding.
 */
import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import ipaddr from 'ipaddr.js';

export interface Download {
  url: string;
  status: number;
  contentType: string;
  body: string;
}

export class AuditFetchError extends Error {
  constructor(message: string, public readonly httpStatus = 422) {
    super(message);
  }
}

function publicAddress(address: string): boolean {
  try {
    const addr = ipaddr.parse(address);
    if (addr.kind() === 'ipv6' && (addr as ipaddr.IPv6).isIPv4MappedAddress()) {
      return publicAddress((addr as ipaddr.IPv6).toIPv4Address().toString());
    }
    return addr.range() === 'unicast';
  } catch {
    return false;
  }
}

function validatedUrl(input: string): URL {
  let url: URL;
  try {
    url = new URL(input);
  } catch {
    throw new AuditFetchError('Enter a valid website URL.', 400);
  }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) {
    throw new AuditFetchError('Only public HTTP(S) websites without credentials are supported.', 400);
  }
  if (url.port && !['80', '443'].includes(url.port)) {
    throw new AuditFetchError('Nonstandard ports cannot be scanned.', 400);
  }
  const host = url.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host.includes('.') || /(^|\.)(localhost|local|internal|onion|test|invalid)$/.test(host)) {
    throw new AuditFetchError('Local and internal hosts cannot be scanned.', 400);
  }
  if (isIP(host) && !publicAddress(host)) {
    throw new AuditFetchError('Private IP addresses cannot be scanned.', 400);
  }
  return url;
}

async function pinnedAddress(hostname: string): Promise<{ address: string; family: 4 | 6 }> {
  const host = hostname.replace(/^\[|\]$/g, '');
  if (isIP(host)) {
    if (!publicAddress(host)) throw new AuditFetchError('Restricted network address.', 400);
    return { address: host, family: isIP(host) as 4 | 6 };
  }
  let addresses: Awaited<ReturnType<typeof lookup>>;
  try {
    addresses = await lookup(host, { all: true, verbatim: true });
  } catch {
    throw new AuditFetchError('The website domain could not be resolved.');
  }
  if (!addresses.length || addresses.some(item => !publicAddress(item.address))) {
    throw new AuditFetchError('The hostname resolves to a private or restricted address.', 400);
  }
  return addresses[0] as { address: string; family: 4 | 6 };
}

export async function downloadPage(urlString: string, maxBytes = 1_500_000, hops = 0): Promise<Download> {
  if (hops > 4) throw new AuditFetchError('The website redirected too many times.');
  const url = validatedUrl(urlString);
  const pinned = await pinnedAddress(url.hostname);
  const transport = url.protocol === 'https:' ? httpsRequest : httpRequest;
  const result = await new Promise<Download | { redirect: string }>((resolve, reject) => {
    const req = transport(url, {
      method: 'GET',
      lookup: (_hostname, _options, callback) => callback(null, pinned.address, pinned.family),
      headers: {
        'User-Agent': 'SEOAuditHub/1.0 (on-page audit)',
        Accept: 'text/html,application/xml,text/xml,text/plain;q=0.9,*/*;q=0.5',
        'Accept-Encoding': 'identity'
      },
      timeout: 9_000,
      maxHeaderSize: 16_384
    }, res => {
      const status = res.statusCode || 0;
      if (status >= 300 && status < 400 && res.headers.location) {
        const redirect = new URL(res.headers.location, url).href;
        res.resume();
        resolve({ redirect });
        return;
      }
      const chunks: Buffer[] = [];
      let bytes = 0;
      res.on('data', (chunk: Buffer) => {
        bytes += chunk.length;
        if (bytes > maxBytes) {
          req.destroy(new AuditFetchError('The page exceeds the scan size limit.'));
        } else {
          chunks.push(chunk);
        }
      });
      res.on('end', () => resolve({
        url: url.href,
        status,
        contentType: String(res.headers['content-type'] || '').toLowerCase(),
        body: Buffer.concat(chunks).toString('utf8')
      }));
      res.on('error', reject);
    });
    req.on('timeout', () => req.destroy(new AuditFetchError('Timed out while fetching the website.')));
    req.on('error', reject);
    req.end();
  }).catch((cause: unknown) => {
    if (cause instanceof AuditFetchError) throw cause;
    throw new AuditFetchError('Unable to fetch the website. It may block automated requests.');
  });

  if ('redirect' in result) return downloadPage(result.redirect, maxBytes, hops + 1);
  return result;
}
