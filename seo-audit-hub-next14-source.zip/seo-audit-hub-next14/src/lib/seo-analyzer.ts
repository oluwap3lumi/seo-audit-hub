import * as cheerio from 'cheerio';
import { downloadPage, AuditFetchError } from './safe-fetch';
import type { AuditCheck, AuditMetrics, AuditResult, Category, Status } from './types';

const clean = (value: string) => value.replace(/\s+/g, ' ').trim();
const meta = ($: cheerio.CheerioAPI, selector: string) => clean($(selector).first().attr('content') || '');
const headings = ($: cheerio.CheerioAPI, selector: string) =>
  $(selector).toArray().map(node => clean($(node).text())).filter(Boolean).slice(0, 100);

async function checkResource(origin: string, path: '/robots.txt' | '/sitemap.xml') {
  try {
    const res = await downloadPage(new URL(path, origin).href, 150_000);
    const text = res.body.trimStart().toLowerCase();
    const isHtml = res.contentType.includes('text/html') || text.startsWith('<!doctype html') || text.startsWith('<html');
    const sitemapXml = /<urlset\b|<sitemapindex\b/i.test(text);
    return {
      status: res.status,
      present: res.status >= 200 && res.status < 300 && !isHtml &&
        (path === '/robots.txt' || sitemapXml)
    };
  } catch {
    return { status: null, present: false };
  }
}

export async function analyzeWebsite(input: string): Promise<AuditResult> {
  const page = await downloadPage(input);
  if (page.status < 200 || page.status >= 400) {
    throw new AuditFetchError(`The website returned HTTP ${page.status}.`);
  }
  if (page.contentType && !page.contentType.includes('html') && !page.contentType.includes('text/plain')) {
    throw new AuditFetchError('This URL did not return an HTML webpage.');
  }

  const $ = cheerio.load(page.body);
  const final = new URL(page.url);
  const title = clean($('title').first().text());
  const description = meta($, 'meta[name="description"]');
  const canonical = clean($('link[rel="canonical"]').first().attr('href') || '');
  const viewport = meta($, 'meta[name="viewport"]');
  const h1 = headings($, 'h1');
  const h2 = headings($, 'h2');
  const h3 = headings($, 'h3');

  const images = $('img').toArray();
  const missingAlt = images.filter(img => $(img).attr('alt') === undefined).length;
  let internalLinks = 0;
  let externalLinks = 0;
  let emptyLinks = 0;
  $('a').each((_, anchor) => {
    const href = $(anchor).attr('href');
    if (href === undefined || !href.trim()) { emptyLinks++; return; }
    if (href.startsWith('#') || /^(javascript:|mailto:|tel:|data:)/i.test(href)) return;
    try {
      const target = new URL(href, page.url);
      if (!['http:', 'https:'].includes(target.protocol)) return;
      const a = final.hostname.replace(/^www\./, '');
      const b = target.hostname.replace(/^www\./, '');
      if (a === b) internalLinks++;
      else externalLinks++;
    } catch { emptyLinks++; }
  });
  const visible = cheerio.load(page.body);
  visible('script,style,noscript,template,svg,nav,footer').remove();
  const bodyText = clean(visible('body').text() || visible.root().text());
  const wordCount = (bodyText.match(/[\p{L}\p{N}]+(?:['’-][\p{L}\p{N}]+)*/gu) || []).length;
  const textHtmlRatio = Math.round(bodyText.length / Math.max(page.body.length, 1) * 1000) / 10;
  const [robots, sitemap] = await Promise.all([
    checkResource(final.origin, '/robots.txt'),
    checkResource(final.origin, '/sitemap.xml')
  ]);

  const metrics: AuditMetrics = {
    title, description, canonical, h1, h2, h3, wordCount, textHtmlRatio,
    images: images.length, missingAlt, internalLinks, externalLinks, emptyLinks,
    robotsStatus: robots.status, sitemapStatus: sitemap.status
  };
  const checks: AuditCheck[] = [];
  const add = (
    id: string, category: Category, label: string, status: Status,
    detail: string, recommendation: string, weight = 4
  ) => checks.push({ id, category, label, status, detail, recommendation, weight });

  add('title', 'meta', 'Page title',
    !title ? 'error' : title.length >= 50 && title.length <= 60 ? 'pass' : 'warning',
    !title ? 'No title tag detected.' : `${title.length} characters. Title: ${title.slice(0, 120)}`,
    'Write a descriptive, unique title with the main topic up front. Aim for roughly 50–60 characters without keyword stuffing.', 10);
  add('description', 'meta', 'Meta description',
    !description ? 'error' : description.length >= 150 && description.length <= 160 ? 'pass' : 'warning',
    !description ? 'No meta description detected.' : `${description.length} characters detected; guideline: 150–160.`,
    'Write a compelling page-specific summary. The 150–160 character target is a guideline, not a direct ranking factor.', 8);
  add('canonical', 'meta', 'Canonical URL', canonical ? 'pass' : 'warning',
    canonical ? `Canonical: ${canonical.slice(0, 140)}` : 'Canonical link not found.',
    'Put a canonical link in the document head pointing to the preferred page URL.', 5);
  add('h1', 'meta', 'Primary H1 heading',
    h1.length === 0 ? 'error' : h1.length === 1 ? 'pass' : 'warning',
    `${h1.length} H1 tag(s).${h1[0] ? ` First: ${h1[0].slice(0, 120)}` : ''}`,
    'Use a meaningful main heading. One H1 is a simple convention; multiple H1s are not automatically penalized.', 9);
  add('h2', 'meta', 'Supporting headings', h2.length > 0 ? 'pass' : 'warning',
    `${h2.length} H2 and ${h3.length} H3 headings.`,
    'Break substantial content into logical H2 and H3 sections where useful.', 3);
  add('wordcount', 'meta', 'Visible page content', wordCount >= 300 ? 'pass' : 'warning',
    `Approximately ${wordCount} visible words found in server-returned HTML.`,
    'Provide complete, helpful content for user intent. Short pages may legitimately contain fewer than 300 words.', 4);
  add('ratio', 'meta', 'Text-to-HTML ratio', textHtmlRatio >= 10 ? 'pass' : 'warning',
    `${textHtmlRatio}% text-to-HTML ratio (heuristic).`,
    'Reduce redundant markup and ensure key copy is available without JavaScript. This ratio is not a Google ranking factor.', 2);

  add('viewport', 'social', 'Mobile viewport', viewport.includes('width=device-width') ? 'pass' : 'warning',
    viewport ? `Viewport: ${viewport.slice(0, 120)}` : 'Viewport meta tag missing.',
    'Add <meta name="viewport" content="width=device-width, initial-scale=1"> to your document head.', 6);
  const socials = [
    ['ogtitle', 'meta[property="og:title"]', 'Open Graph title', 'Add an og:title with an engaging social headline.'],
    ['ogdescription', 'meta[property="og:description"]', 'Open Graph description', 'Add an og:description for link sharing previews.'],
    ['ogimage', 'meta[property="og:image"]', 'Open Graph image', 'Provide a public og:image URL for link previews.'],
    ['twitter', 'meta[name="twitter:card"]', 'Twitter/X card', 'Add a twitter:card meta tag (e.g. summary_large_image).']
  ] as const;
  for (const [id, selector, label, fix] of socials) {
    const value = meta($, selector);
    add(id, 'social', label, value ? 'pass' : 'warning',
      value ? `Present: ${value.slice(0, 130)}` : 'Social meta tag missing.', fix, 3);
  }

  add('alt', 'media', 'Image alt attributes', missingAlt ? 'warning' : 'pass',
    `${missingAlt} of ${images.length} images are missing an alt attribute.`,
    'Describe informative images using alt text. Decorative images should use alt="".', 7);
  add('internal', 'media', 'Internal linking', internalLinks ? 'pass' : 'warning',
    `${internalLinks} internal and ${externalLinks} external links detected.`,
    'Link relevant related pages to improve discoverability, where appropriate.', 4);
  add('empty', 'media', 'Empty or invalid links', emptyLinks ? 'warning' : 'pass',
    `${emptyLinks} empty or invalid link URLs detected.`,
    'Give navigation anchors real destinations, and use buttons for actions.', 5);

  add('https', 'technical', 'HTTPS security', final.protocol === 'https:' ? 'pass' : 'error',
    final.protocol === 'https:' ? 'Website fetched via HTTPS.' : 'Website uses unencrypted HTTP.',
    'Configure HTTPS with a valid certificate and redirect HTTP requests to HTTPS.', 10);
  add('robots', 'technical', 'Robots.txt', robots.present ? 'pass' : 'warning',
    robots.present ? `robots.txt available (HTTP ${robots.status}).` : `robots.txt not confirmed${robots.status ? ` (HTTP ${robots.status})` : ''}.`,
    'Provide /robots.txt when you need crawler directives. Its absence alone is not an SEO failure.', 4);
  add('sitemap', 'technical', 'XML sitemap', sitemap.present ? 'pass' : 'warning',
    sitemap.present ? 'Valid sitemap structure found at /sitemap.xml.' : 'No valid sitemap confirmed at /sitemap.xml.',
    'Publish an XML sitemap or declare its actual location in robots.txt.', 5);

  const weight = checks.reduce((sum, check) => sum + check.weight, 0);
  const score = Math.round(100 * checks.reduce((sum, check) =>
    sum + check.weight * (check.status === 'pass' ? 1 : check.status === 'warning' ? 0.5 : 0), 0) / weight);

  return {
    requestedUrl: input,
    url: page.url,
    auditedAt: new Date().toISOString(),
    score,
    summary: {
      errors: checks.filter(x => x.status === 'error').length,
      warnings: checks.filter(x => x.status === 'warning').length,
      passed: checks.filter(x => x.status === 'pass').length
    },
    metrics,
    checks
  };
}
