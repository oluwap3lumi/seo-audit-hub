export function normalizeUrl(raw: string): string {
  const value = raw.trim();
  if (!value) throw new Error('Enter a website URL to start your audit.');
  const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
  if (!['https:', 'http:'].includes(url.protocol) || !url.hostname.includes('.') || url.username || url.password) {
    throw new Error('Enter a valid public website URL, for example example.com.');
  }
  if (url.port && !['80', '443'].includes(url.port)) {
    throw new Error('Only standard web ports are supported.');
  }
  return url.href;
}
