import { NextRequest, NextResponse } from 'next/server';
import { analyzeWebsite } from '@/lib/seo-analyzer';
import { AuditFetchError } from '@/lib/safe-fetch';
import { normalizeUrl } from '@/lib/url';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest) {
  let body: unknown;
  try { body = await request.json(); }
  catch { return NextResponse.json({ error: 'Expected a JSON object with a url field.' }, { status: 400 }); }
  const urlValue = (body || {}) as { url?: unknown };
  if (typeof urlValue.url !== 'string' || urlValue.url.length > 2048) {
    return NextResponse.json({ error: 'Enter a valid website URL.' }, { status: 400 });
  }
  try {
    const url = normalizeUrl(urlValue.url);
    const report = await analyzeWebsite(url);
    return NextResponse.json(report, { headers: { 'Cache-Control': 'no-store' } });
  } catch (err) {
    const status = err instanceof AuditFetchError ? err.httpStatus : err instanceof TypeError ? 400 : 422;
    const message = err instanceof Error ? err.message : 'Unable to audit this website.';
    return NextResponse.json({ error: message }, { status });
  }
}
