import type { Metadata } from 'next';
import './globals.css';
import Providers from './providers';

export const metadata: Metadata = {
  title: 'SEO Audit Hub — Free Website SEO Checker',
  description: 'Instantly analyze any website’s on-page SEO: titles, headings, images, links, HTTPS, robots.txt, sitemaps, and more.'
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body><Providers>{children}</Providers></body></html>;
}
