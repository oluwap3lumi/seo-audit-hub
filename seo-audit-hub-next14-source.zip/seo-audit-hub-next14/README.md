# SEO Audit Hub — Next.js 14 App Router edition

A responsive, free, single-page SEO audit application. Enter a public website URL to inspect page metadata, heading structure, social sharing tags, images, links, HTTPS, robots.txt, and XML sitemap. Results include a 0–100 **heuristic**, plain-language fixes, filtered audit details, PDF printing, clipboard summaries, dark mode, and the last 10 browser-saved reports.

## Getting started

1. Install **Node.js 20 LTS or newer** and npm.
2. Extract this folder and open a terminal in it.
3. Run `npm install`.
4. Run `npm run dev`.
5. Visit <http://localhost:3000>.
6. Enter a public site such as `example.com` and select **Audit Website**.
7. Run `npm run typecheck` and `npm run build` before deployment.
8. For production, run `npm run build && npm run start` on a Node-capable host, or deploy the repository to Vercel as a **server-rendered Next.js application** (do not enable static export).

No API keys or database required. The backend is a Next.js Node.js route at `src/app/api/audit/route.ts`.

## Project structure

```text
seo-audit-hub-next14/
├── src/
│   ├── app/
│   │   ├── api/audit/route.ts       # POST /api/audit; validates input, handles errors
│   │   ├── globals.css              # Design tokens, themes, printing
│   │   ├── layout.tsx                # Root layout and SEO metadata
│   │   ├── page.tsx                  # App Router homepage
│   │   └── providers.tsx             # TanStack Query client
│   ├── components/
│   │   ├── audit-dashboard.tsx       # Form, results, category tabs, recent history
│   │   ├── score-ring.tsx            # Accessible radial score indicator
│   │   └── ui/
│   │       ├── button.tsx            # shadcn-style reusable button
│   │       └── card.tsx              # shadcn-style reusable card
│   └── lib/
│       ├── safe-fetch.ts            # SSRF-safe, size-limited, timeout-limited fetching
│       ├── seo-analyzer.ts          # Cheerio SEO analysis and weighted scoring
│       ├── types.ts                 # Typed result and check contracts
│       ├── url.ts                   # URL normalization/validation
│       └── utils.ts                 # shadcn class merging
├── package.json
├── next.config.mjs
├── postcss.config.js
├── tailwind.config.ts
├── tsconfig.json
└── README.md
```

## API example

```bash
curl -X POST http://localhost:3000/api/audit \
  -H 'Content-Type: application/json' \
  -d '{"url":"https://example.com"}'
```

A successful response includes `url`, `auditedAt`, `score`, `summary`, `metrics`, and categorized `checks`. A non-2xx response returns `{ "error": "..." }`.

## Architecture and accuracy

- The frontend uses Next.js 14 App Router, React 18, Tailwind, TanStack Query, Lucide, and shadcn-style UI primitives.
- The backend uses a Next.js API route and Cheerio; no remote paid SEO API is needed.
- A website fetch checks DNS address ranges, pins the resolved public address for the outgoing request, checks redirect targets, uses a 9-second per-request timeout, and limits response bytes.
- The score is a **transparent heuristic**: pass = full check weight, warning = half weight, error = zero. It does not predict rankings.
- This checks the **server-returned HTML of one URL**. Client-rendered content, Core Web Vitals, JavaScript, index status, backlink quality, schema validation and real Google rankings are **not measured**.
- Sites may block automated fetches (for example 403, anti-bot, or CAPTCHA). A missing robots.txt is not necessarily harmful; similarly word count and text-to-HTML ratio are advisory rather than ranking factors.
- Some sites declare sitemaps at a path other than `/sitemap.xml`, which this version will warn about.
- The server does not crawl the whole site or store visitor audit data. Browser audit history uses localStorage only.

## Production hardening before public scale

Use reverse-proxy/WAF rate limiting, abuse quotas, monitoring, request and error logging with safe URL redaction, privacy terms, and a robust egress policy. Place the audit service in a network segment that cannot reach internal resources; app-level SSRF checks supplement but do not replace network isolation. Keep Next.js, Node.js and dependencies patched.

The hosted AppDeploy version uses a different supported deployment scaffold: a static Next.js frontend plus an AppDeploy Node backend. This local project is an independent, idiomatic **Next.js 14 App Router** version of the same functional concept.
