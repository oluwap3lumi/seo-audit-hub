import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: { 50: '#f3f1ff', 500: '#705cf1', 600: '#6553eb', 700: '#5240d0' }
      }
    }
  },
  plugins: []
};
export default config;
